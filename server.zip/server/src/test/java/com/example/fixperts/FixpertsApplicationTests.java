package com.example.fixperts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FixpertsApplicationTests {

	@Test
	void contextLoads() {
	}

}
